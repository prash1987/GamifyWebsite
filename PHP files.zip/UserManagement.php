<!DOCTYPE html>
<html>
<head>
	<title>Let's Play</title>
</head>
<body>

<br>Let's Play Administration Page<br>

<?php
// if the $_POST is NOT empty (i.e. has some stuff in it) then something has been posted:
if (!empty($_POST)): ?>

    <?php
    $user_name = $_POST["user_name"];

    $servername = "localhost";
    $username = "root";
    $password = "1234567";
    $dbname = "sys";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

	if($user_name === 'No') {
		echo "User table is empty";
	}
	else {
		$sql = "DELETE FROM User WHERE First_name='$user_name'";

		if ($conn->query($sql) === TRUE) {
			echo "User Deleted successfully";
			//Remove the entry from dropdown box
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
		}
	}
    $conn->close();

	?>

<?php else: ?>

    <?php

    $servername = "localhost";
    $username = "root";
    $password = "1234567";
    $dbname = "sys";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT User_id, First_name FROM User";
    $result = $conn->query($sql);
    ?>

	<form action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> method="post">

	<?php

    if ($result-> num_rows > 0) {
        echo "User Name: ";
        echo "<select name='user_name'>";
		while($row = $result->fetch_assoc()) {
			echo '<option value="'.$row["First_name"].'">'.$row["First_name"].'</option>';
        }
        echo "</select>";
    } else {
    	echo "<select name='user_name'>";
    	echo '<option value="No">No user found</option>';
    	echo "</select>";
    }

    $conn->close();

    ?>

    <input type="submit" value="Delete User">
    </form>
<?php endif; ?>
</body>
</html>