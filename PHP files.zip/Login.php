<!DOCTYPE html>
<html>
<head>
	<title>Let's Play</title>
</head>
<body>

<br>Let's Play Administration Page<br>

<?php
// if the $_POST is NOT empty (i.e. has some stuff in it) then something has been posted:
if (!empty($_POST)): ?>

    <?php
    $user_id = $_POST["user_id"];
    $passwd = $_POST["passwd"];

    $servername = "localhost";
    $username = "root";
    $password = "1234567";
    $dbname = "sys";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT User_id FROM Login WHERE User_id='Admin' AND User_id='$user_id' AND Password='$passwd'";
	$res = $conn->query($sql);
    if ($res->num_rows > 0) {
        echo "Logged in successfully";
    } else {
        echo "Error while logging in: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();

	?>

<?php else: ?>
    <form action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> method="post">
        User Name: <input type="text" name="user_id" required="this field is empty"><br>
        Password: <input type="password" name="passwd" required="this field is empty"><br>
        <input type="submit">
    </form>
<?php endif; ?>
</body>
</html>