<!DOCTYPE html>
<html>
<head>
	<title>Let's Play</title>
</head>
<body>

<br>Let's Play Administration Page<br>

<?php
// if the $_POST is NOT empty (i.e. has some stuff in it) then something has been posted:
if (!empty($_POST)): ?>

    <?php
    $location = $_POST["location"];

    $servername = "localhost";
    $username = "root";
    $password = "1234567";
    $dbname = "sys";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO Location(Name) VALUES('$location')";

    if ($conn->query($sql) === TRUE) {
        echo "Location added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();

	?>

<?php else: ?>
    <form action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> method="post">
        Location: <input type="text" name="location" required="this field is empty"><br>
        <input type="submit" value="Add Location">
    </form>
<?php endif; ?>
</body>
</html>