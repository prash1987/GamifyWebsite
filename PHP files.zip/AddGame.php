<!DOCTYPE html>
<html>
<head>
	<title>Let's Play</title>
</head>
<body>

<br>Let's Play Administration Page<br>

<?php
// if the $_POST is NOT empty (i.e. has some stuff in it) then something has been posted:
if (!empty($_POST)): ?>

    <?php
    $game_name = $_POST["game_name"];;

    $servername = "localhost";
    $username = "root";
    $password = "1234567";
    $dbname = "sys";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO Game(Name) VALUES('$game_name')";

    if ($conn->query($sql) === TRUE) {
        echo "Game added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();

	?>

<?php else: ?>
    <form action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> method="post">
        User Name: <input type="text" name="game_name" required="this field is empty"><br>
        <input type="submit" value="Add Game">
    </form>
<?php endif; ?>
</body>
</html>